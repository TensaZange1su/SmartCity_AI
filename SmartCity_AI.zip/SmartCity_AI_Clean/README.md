# SmartCity_AI
AI-walking assistant in Kazakhstan

#  SmartCity AI Recommender

**SmartCity AI** — интеллектуальная система рекомендаций для города **Астаны**.  
Она объединяет **NLP**, **LLM (GPT-4o-mini)**, **Sentence Transformers**, **геолокацию** и **семантический поиск**, чтобы находить **релевантные точки интереса (POI)** по пользовательским запросам на естественном языке.

---

## Возможности

 Понимание запросов пользователей (на русском и английском языках)  
 Семантический поиск с Sentence Transformers  
 Реранкинг результатов через CrossEncoder  
 Географическая фильтрация по радиусу  
 Контекстная фильтрация через LLM (GPT-4o-mini)  
 Классификация намерений пользователя (zero-shot)  
 Визуализация точек на карте (Streamlit + Folium)  
 Поддержка сценариев — "еда", "природа", "развлечения", "дети", "ночь" и др.

---

##  Архитектура системы

```text
User Query
   │
   ▼
Intent Classifier (Zero-Shot, BART-MNLI)
   │
   ▼
Semantic Search (SentenceTransformer)
   │
   ▼
Reranking (CrossEncoder)
   │
   ▼
LLM Filter (GPT-4o-mini via OpenAI API)
   │
   ▼
Map Visualization (Streamlit + Folium)

## Установка
1.Клонирование проекта
git clone https://github.com/<your_username>/SmartCity_AI.git
cd SmartCity_AI

2️.Установка зависимостей
pip install -r requirements.txt


## PyTorch автоматически установится в CPU-режиме, если не обнаружена GPU.

##  Настройка окружения
Создай файл .env в корне проекта и добавь свой OpenAI API ключ:

OPENAI_API_KEY=sk-********************************

##  Запуск приложения
streamlit run main.py


После запуска открой в браузере:
http://localhost:8501

##  Используемые модели

Семантический поиск	sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2	Поиск по смыслу
Реранкинг	cross-encoder/ms-marco-MiniLM-L-6-v2	Повышение точности выдачи
Классификация намерений	facebook/bart-large-mnli	Определение цели запроса
LLM фильтрация	gpt-4o-mini (через OpenAI API)	Контекстная фильтрация
Геолокация	geopy, osmnx, folium	Расчёт расстояний и визуализация


##  Пример использования

Запрос: «Хочу место для прогулки на природе»
Результат:
🌿 Президентский парк — Природные объекты (4.05 км от вас)
🌿 Набережная Есиля — Места отдыха (2.3 км от вас)
☕ Кафе у парка — Общественное питание (2.1 км от вас)

##  Поддерживаемые сценарии запросов
🌿 Природа и отдых	«Парк для прогулки», «Природные места», «Покататься на велосипеде»
☕ Еда и напитки	«Где поесть рядом», «Лучшие кафе», «Кофейня рядом»
🌙 Ночная жизнь	«Куда сходить вечером», «Бар с друзьями», «Караоке»
👶 Семейный отдых	«Место для прогулки с детьми», «Семейный центр»
🎭 Развлечения	«Кино», «Квест», «Театр», «Развлечения поблизости»
💆 Красота и здоровье	«Спа», «Массаж», «Фитнес», «Йога»
💻 Developer Notes

Для улучшения качества рекомендаций можно заменить LLM-модель:
gpt-4o-mini → gpt-4-turbo для более глубокой фильтрации
или использовать локальную LLM (например, llama-3, mistral, phi-3) через API совместимости

## Векторизация выполняется один раз при инициализации — эмбеддинги сохраняются в DataFrame

## Поддерживается мультиязычный ввод запросов

##  Requirements
# Core scientific stack
numpy==1.26.4
pandas==2.2.2
scikit-learn==1.5.2

# Deep learning (CPU build)
torch==2.3.1+cpu
torchvision==0.18.1+cpu
torchaudio==2.3.1+cpu
--index-url https://download.pytorch.org/whl/cpu

# Transformers & NLP
transformers==4.40.2
sentence-transformers==2.2.2
huggingface-hub==0.23.4

# Web app
streamlit==1.40.0
folium==0.16.0
geopy==2.4.1
requests==2.32.3
python-dotenv==1.0.1

# Dependency fixes
packaging==24.1
fsspec==2024.6.1

# Local direction & mapping
osmnx==1.3.0
networkx==3.1
streamlit-geolocation==0.0.10

##  Лицензия

EcoFlow Team
Разработано для демонстрации интеллектуальных рекомендаций на основе LLM и трансформеров.
